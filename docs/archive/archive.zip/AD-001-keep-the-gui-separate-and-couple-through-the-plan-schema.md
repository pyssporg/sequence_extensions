---
id: AD-001
title: Keep the GUI repo separate and couple through the engine's plan schema
summary: The GUI stays a separate package and validates plan documents against the engine's normative flow-plan/2 JSON Schema.
date: 2026-11-13
status: accepted
layers: [architecture, implementation]
state: 02-architecture/gui-application/how-the-gui-stays-decoupled-from-the-engine.md
artifacts:
  - pyproject.toml
  - .github/workflows/tests.yml
  - gui/src/seq_ext_gui/schema.py
  - gui/src/seq_ext_gui/contracts.py
  - gui/src/seq_ext_gui/engine.py
  - gui/tests/test_schema.py
supersedes: []
superseded_by: [AD-002]
related: []
---

# AD-001: Keep the GUI repo separate and couple through the engine's plan schema

## Context
Asked whether to merge the GUI into the engine repository. Coupling is already two import statements and seven public symbols. A shared repo would put the GUI's FastAPI stack inside a package that holds zero runtime dependencies. The GUI's hand-written pydantic mirror of the plan document had to change with every engine edit.

## Decision
On 2026-11-13 the GUI stayed a separate repository. The engine publishes the normative `flow-plan/2` JSON Schema as `flow.plan_schema()` and `schemas/flow-plan-2.schema.json`. The GUI validates plan documents against that artifact with `jsonschema` (`Draft202012Validator`, draft 2020-12) instead of mirroring them. Superseded on 2026-11-19 by `AD-002`, which moved the GUI into the engine repository.

## Rationale
Public-API coupling is narrow enough that a merge buys little. The engine keeps its zero-runtime-dependency contract; the GUI keeps FastAPI and uvicorn. Engine 3.0.1 is not on PyPI, so the GUI git-pins `ac7e0e5`. Commit `fc22bcf` had already de-coupled the plan document deliberately, and the published schema finishes that work.

## Alternatives Considered
- Merge the GUI into the engine repository.
- Keep pydantic mirrors of the plan document in the GUI.
- Copy the schema into the GUI and maintain it there.

## Consequences
- Positive: the engine owns the document shape once; the GUI follows by validation; no Python mirror can drift.
- Negative: the GUI must pin an engine revision that ships the schema; a stale engine fails only when a plan is validated.

## Verification
`tests/test_schema.py` validates good and bad documents, checks path-named errors, and exercises the `plan_schema()` fallback (`TEST-001`).

## Review Trigger
The engine changes the `flow-plan/2` document without publishing a schema, or drops `plan_schema()`.
