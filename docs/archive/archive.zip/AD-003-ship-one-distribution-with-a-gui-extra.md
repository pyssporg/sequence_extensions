---
id: AD-003
title: Ship one distribution with a GUI extra
summary: One distribution, sequence-extensions-flow, puts the GUI behind the gui extra; the base install stays zero-dependency.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/gui-application/how-the-gui-stays-decoupled-from-the-engine.md
artifacts:
  - pyproject.toml
  - src/sequence_extensions
  - src/seq_ext_gui
supersedes: [AD-002]
superseded_by: []
related: []
---

# AD-003: Ship one distribution with a GUI extra

## Context
- `AD-002` merged the GUI into the engine repository but kept two distributions: `sequence-extensions-flow` and `sequence-extensions-gui`.
- Two distributions in one repo duplicate version, release, and install metadata for no gain; both build from the same tree and always ship together.

## Decision
- On 2026-11-19 the repo flattened to one distribution, `sequence-extensions-flow`, at the repo root.
- The GUI moved behind a `gui` extra: `pip install "sequence-extensions-flow[gui]"`; development installs `pip install -e ".[dev,gui]"`.
- The base install keeps zero runtime dependencies; the GUI's FastAPI stack arrives only with the extra.
- One version, `sequence_extensions.__version__`, serves both; `seq_ext_gui` re-exports it.
- The dependency stays one-way: the GUI imports the engine; the engine imports nothing from `seq_ext_gui`.

## Rationale
- The GUI is the engine's only first-party consumer, so an independent release buys nothing.
- One project file, one version, and one release cover both packages.
- The extra keeps the engine's zero-dependency guarantee intact for library users.

## Alternatives Considered
- Keep two distributions (`AD-002`): correct, but duplicates version, release, and install metadata.
- Put the GUI in the base install: the FastAPI stack would enter the engine's dependency set.

## Consequences
- Positive: one version, one release, and one install path; the base install stays zero-dependency.
- Negative: the engine wheel now carries GUI static assets, and the GUI dependencies appear in one project file.

## Verification
`pip install -e ".[dev,gui]"` gives both packages in one `.venv`, and `pb check --strict` passes (`TEST-003`).

## Review Trigger
The GUI gains an audience that needs an independent release, or the extra's install cost outweighs the metadata it removes.
