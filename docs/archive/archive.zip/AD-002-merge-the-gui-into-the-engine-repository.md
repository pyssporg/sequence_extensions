---
id: AD-002
title: Merge the GUI into the engine repository
summary: One repo ships two distributions; the GUI under gui/ depends one-way on the zero-dependency engine at the repo root.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: 02-architecture/gui-application/how-the-gui-stays-decoupled-from-the-engine.md
artifacts:
  - pyproject.toml
  - gui/pyproject.toml
supersedes: [AD-001]
superseded_by: [AD-003]
related: []
---

# AD-002: Merge the GUI into the engine repository

## Context
- 2026-11-13 kept the GUI in its own repository and coupled it through the published plan schema (`AD-001`).
- The GUI is the engine's only first-party consumer; the plan contract changes on both sides of the boundary.
- The GUI git-pins engine tag `v3.1.0`, so every contract change needs a tag round-trip before the GUI can follow.
- Engine 3.1.0 is not on PyPI; the git pin is the only install path for the GUI.

## Decision
- On 2026-11-19 the GUI moved into the engine repository: one repo, two distributions.
- `sequence-extensions-flow` stays at the repo root with zero runtime dependencies.
- `sequence-extensions-gui` lives under `gui/` and keeps FastAPI, uvicorn, and `jsonschema`.
- The dependency stays one-way: the GUI imports the engine; the engine never imports the GUI.
- Superseded on 2026-11-19 by `AD-003`: one distribution with a `gui` extra.

## Rationale
- One first-party consumer: a separate repository buys no independent audience.
- The contract co-evolves: an engine schema edit and the GUI validation that follows land together.
- Atomic cross-package change: one commit updates engine, GUI, and tests.
- No git-tag pin remains, so a contract change no longer waits for a release round-trip.

## Alternatives Considered
- Keep two repositories and the schema-plus-tag coupling (`AD-001`).
- Merge into one distribution: the GUI's FastAPI stack would enter the zero-dependency engine.

## Consequences
- Positive: one commit carries a contract change across both packages; one CI run covers both suites.
- Negative: the repo carries a second dependency set, and releases must publish both distributions.

## Verification
The merged tree passes `pb check --strict`; the engine and GUI suites run from one checkout (`TEST-003`).

## Review Trigger
The GUI gains a second consumer outside this repo, or the engine needs to depend on the GUI.
