---
id: AD-004
title: One headless run API in flow_runner behind both frontends
summary: One headless run API lives in flow_runner, not flow, so both frontends stay thin adapters and the engine-core budget holds.
date: 2026-11-19
status: accepted
layers: [architecture, implementation]
state: docs/breakdown/02-architecture/gui-application/how-the-gui-stays-decoupled-from-the-engine.md
artifacts:
  - src/sequence_extensions/flow_runner/headless.py
  - src/sequence_extensions/flow_runner/__init__.py
  - src/seq_ext_gui/engine.py
supersedes: []
superseded_by: []
related: [INFO-003, INFO-047, IMP-037, DR-021]
---

# AD-004: One headless run API in flow_runner behind both frontends

## Context
- `IMP-037`: the GUI worker re-derived module loading, flow selection, the schema gate, planning, override application, execution, and run projection beside the CLI.
- The engine core (`flow` + `graph`) was 4,970 lines against its 5,000-line hard budget (`DR-021`), so a new public module could not live in `flow`.
- `flow_runner` already owned module discovery and was already imported by the GUI.

## Decision
- On 2026-11-19 the headless run API landed in `src/sequence_extensions/flow_runner/headless.py`.
- It exports `HeadlessRun`, `load_flow_module`, `select_flow`, `require_plan_document`, and `run_flow`.
- `flow_runner/__init__.py` became the CLI adapter over it; the GUI `engine.py` imports the same five names.
- Both frontends keep only their own policy; neither re-derives loading, selection, the schema gate, or run projection.

## Rationale
- One unit gives one schema gate, one selection message, and one run projection, so a wording change reaches both frontends.
- `flow` is the shipped library core under a hard ceiling; `flow_runner` is the adapter package.
- The GUI already imported `find_nodes` from `flow_runner`, so the dependency direction did not change.

## Alternatives Considered
- Put the headless API in `flow`: rejected; the core was at 4,970 of 5,000 lines (`DR-021`).
- Keep the two copies and align them by test: rejected; drift is the defect this removes.

## Consequences
- Positive: one implementation; CLI flags, exit codes, and stdout wording stay unchanged.
- Positive: the GUI `engine.py` fell from 615 to 524 lines and keeps root-seed validation, warnings, wire annotation, schema-artifact validation, subprocess isolation, SSE, and confinement.
- Negative: both frontends now depend on the `flow_runner.headless` public surface, so a rename there reaches both.

## Verification
`tests/runner/test_headless.py` covers loading, selection, the gate, the run unit, `cwd`, and projection; the runner and GUI suites pass unchanged.

## Review Trigger
The headless API needs a name or shape the `flow_runner` adapter package cannot own, or `IMP-020` splits the engine core and frees the placement constraint.
